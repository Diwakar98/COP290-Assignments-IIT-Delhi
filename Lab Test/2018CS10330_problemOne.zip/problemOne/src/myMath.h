#ifndef MYMATH_H
#define MYMATH_H

double myFactorial(int);
double nCr(int,int);
double mySin();
double myCos();

#endif
